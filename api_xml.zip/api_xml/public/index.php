<?php
    require '../vendor/autoload.php';
    require '../src/configs/DBAccess.php';

    // API main routes
    require '../src/routes/jsonapi.php';
?>