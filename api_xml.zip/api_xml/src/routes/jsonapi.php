<?php
    use Psr\Http\Message\ServerRequestInterface as Request;
    use Psr\Http\Message\ResponseInterface as Response;

    require '../vendor/autoload.php';

    function message ($status,$message,$object=null) {
        if ($object == null) {
            return array("status" => $status, "message" => $message);
        } else {
            return array("status" => $status, "message" => $message, "voisins" => $object);
        }        
    }

    $app = new \Slim\App;
    /**
     * route - CREATE - add new neighbor - POST method
     */
    $app->post
    (
        '/api/voisin', 
        function (Request $request, Response $old_response) {
            try {
                $params = $request->getQueryParams();
                $id = $params['id'];
                $nom = $params['nom'];
                $numero = $params['numero'];
                $adresse = $params['adresse'];
                $commentaire = $params['commentaire'];

                $sql = "insert into T_Users (id,nom,numero,adresse,commentaire) values (:id,:nom,:numero,:adresse,:commentaire)";

                $db_access = new DBAccess ();
                $db_connection = $db_access->getConnection();

                $statement = $db_connection->prepare($sql);
                $statement->bindParam(':id', $id);
                $statement->bindParam(':nom', $nom);
                $statement->bindParam(':numero', $numero);
                $statement->bindParam(':adresse', $adresse);
                $statement->bindParam(':commentaire', $commentaire);
                $statement->execute();
                
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message('OK', "The neighbor has been added successfully.")));
            } catch (Exception $exception) {
                
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message('KO', $exception->getMessage())));
            }

            return $response;
        }
    );


    /**
     * route - READ - get neighbor by id - GET method
     */
    $app->get
    (
        '/api/voisin/{id}', 
        function (Request $request, Response $old_response) {
            try {
                $id = $request->getAttribute('id');                

                $sql = "select * from T_Users where id = :id";

                $db_access = new DBAccess ();
                $db_connection = $db_access->getConnection();

                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();

                $statement = $db_connection->prepare($sql);
                $statement->execute(array(':id' => $id));
                if ($statement->rowCount()) {
                    $etudiant = $statement->fetch(PDO::FETCH_OBJ);                    
                    $body->write(json_encode($etudiant));
                }
                else
                {
                    $body->write(json_encode(message('KO', "The neighbor with id = '".$id."' has not been found or has been deleted.")));
                }

                $db_access->releaseConnection();
            } catch (Exception $exception) {
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message('KO', "Unable to connect to the data base.")));
            }
            
            return $response;
        }
    );

    /**
     * route - READ - get all neighbors - GET method
     */
    $app->get
    (
        '/api/voisins', 
        function (Request $request, Response $old_response) {
            try {
                $sql = "Select * From T_Users";
                $db_access = new DBAccess ();
                $db_connection = $db_access->getConnection();
    
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();

                $statement = $db_connection->query($sql);
                if ($statement->rowCount()) {
                    $voisins = $statement->fetchAll(PDO::FETCH_OBJ);                    
                    $body->write(json_encode(array("voisins" => $voisins)));
                } else {
                    $body->write(json_encode(message('KO', "No neighbor has been recorded yet.")));
                }

                $db_access->releaseConnection();
            } catch (Exception $exception) {
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(array("code" => 500, "status" => 'KO', "message" => "Unable to connect to the data base.")));
            }
    
            return $response;
        }
    );

    
    /**
     * route - DELETE - delete a neighbors by id - DELETE method
     */
    $app->delete
    (
        '/api/voisin/{id}', 
        function (Request $request, Response $old_response) {
            try {
                $id = $request->getAttribute('id');

                $sql = "delete from T_Users where id = :id";

                $db_access = new DBAccess ();
                $db_connection = $db_access->getConnection();

                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();

                $statement = $db_connection->prepare($sql);
                $statement->execute(array(':id' => $id));

                $body->write(json_encode(message('OK', "The neighbor has been deleted successfully.")));
                $db_access->releaseConnection();
            } catch (Exception $exception) {
                $response = $old_response->withHeader('Content-type', 'application/json');
                $body = $response->getBody();
                $body->write(json_encode(message('KO', "Unable to connect to the data base.")));
            }

            return $response;
        }
    );

    $app->run();
?>